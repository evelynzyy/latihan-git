<section>
    <h1><?php echo $judul ?></h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur eos, doloremque consequuntur error a recusandae laudantium veniam, nemo excepturi quae, quod eligendi? Illo, est quo laboriosam sint corporis cum mollitia. Similique molestiae rerum consequuntur est quibusdam eum minima ut voluptatem porro laudantium illo natus, cumque tenetur accusantium dicta commodi neque?</p>
</section>