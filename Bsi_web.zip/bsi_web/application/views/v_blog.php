<section>
<h1><?php echo $judul ?></h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam mollitia maiores, quo deleniti perspiciatis excepturi, dolorum natus recusandae culpa cupiditate iste quos non fugit dolores incidunt fugiat ut praesentium porro asperiores consequuntur odit officia ex at saepe! Reiciendis sapiente adipisci, repellat aut dolorem culpa inventore blanditiis. Consequatur repellendus ex est!</p>
</section>