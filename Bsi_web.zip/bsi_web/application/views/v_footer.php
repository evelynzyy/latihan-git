        <footer>
            <a href="bsi.ac.id">WEBSITE RESMI UBSI</a>
        </footer>
    </div>
</body>
</html>