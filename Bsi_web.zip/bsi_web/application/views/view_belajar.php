<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyBiodata</title>
</head>
<body>
    ==================================
    <h1>Barang</h1>
    <h2>No. Barang : <?php echo $no_barang;?></h2>
    <h2>Nama Barang : <?php echo $nama_barang;?></h2>
    <h2>QTY : <?php echo $qty;?></h2>
</body>
</html>