<section>
        <h1><?php echo $judul ?></h1>
        <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium, delectus. Blanditiis suscipit quasi explicabo officiis repudiandae eum, quo nisi recusandae cum pariatur ad commodi iste, mollitia est assumenda totam non?
        </p>
</section>
